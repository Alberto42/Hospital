//
// Created by albert on 22.03.16.
//

#ifndef HOSPITAL1_TEST_H
#define HOSPITAL1_TEST_H

void testCutFirstWord();

void debugInputStruct(InputStruct *i);

void testLoadArgumentsOfNewDiseaseEnter ();

void testParse();
#endif //HOSPITAL1_TEST_H
