/*
 * hospital.h
 *
 *  Created on: 15 mar 2016
 *      Author: albert
 */

#ifndef HOSPITAL_H_
#define HOSPITAL_H_



#endif /* HOSPITAL_H_ */
