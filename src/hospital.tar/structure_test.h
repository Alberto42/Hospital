/*
 * structure_test.h
 *
 *  Created on: 22 mar 2016
 *      Author: albert
 */

#ifndef STRUCTURE_TEST_H_
#define STRUCTURE_TEST_H_

void newDiseaseEnterDescriptionTest();
void changeDescriptionTest();

#endif /* STRUCTURE_TEST_H_ */
